//
// Created by xx on 2018/7/15.
//

#ifndef MEDIA_SPIDER_SHA1_H
#define MEDIA_SPIDER_SHA1_H



typedef unsigned long long u_64;
typedef unsigned long u_32;
typedef unsigned char u_char;
void sha_1(u_char *s,u_64 total_len,u_32 *hh);

#endif //MEDIA_SPIDER_SHA1_H
